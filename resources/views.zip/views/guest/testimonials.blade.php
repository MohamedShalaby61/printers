<section class="testmonials pd-norm-sec text-center" id="testmonials">
            <div class="container">
                <h2 class="mb-15">أراء العملاء</h2>
                <p class="mb-30">بعض النمازج من أراء الناس عن شغلنا.</p>
                <div class="owl-carousel owl-theme owl-loaded owl-drag">
                  <div class="owl-stage-outer">
                      <div class="owl-stage">
                          <div class="owl-item active">
                              <div class="item">
                                 <div class="card">
                                    <div class="media">
                                    <img src="{{url('/front/imgs/128.jpg')}}" class="align-self-start mr-3" alt="...">
                                    <div class="media-body">
                                        <h5 class="mt-0">غاده محمد</h5>
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star def-star"></i>
                                            <i class="fas fa-star def-star"></i>
                                        </div>
                                    </div>
                                </div>
                                  <div class="card-body">
                                    <p class="card-text">هذه المنصة رائعه ف طريقة الكتابة والتنسيق ودايما بيبهروني بكل اللي بيعملوه</p>
                                  </div>
                                 </div>
                              </div>
                          </div>
                          <div class="owl-item active">
                              <div class="item">
                                 <div class="card">
                                    <div class="media">
                                    <img src="{{url('/front/imgs/128.jpg')}}" class="align-self-start mr-3" alt="...">
                                    <div class="media-body">
                                        <h5 class="mt-0">غاده محمد</h5>
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star def-star"></i>
                                            <i class="fas fa-star def-star"></i>
                                        </div>
                                    </div>
                                </div>
                                  <div class="card-body">
                                    <p class="card-text">هذه المنصة رائعه ف طريقة الكتابة والتنسيق ودايما بيبهروني بكل اللي بيعملوه</p>
                                  </div>
                                 </div>
                              </div>
                          </div>
                          <div class="owl-item active">
                              <div class="item">
                                 <div class="card">
                                    <div class="media">
                                    <img src="{{url('/front/imgs/128.jpg')}}" class="align-self-start mr-3" alt="...">
                                    <div class="media-body">
                                        <h5 class="mt-0">غاده محمد</h5>
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star def-star"></i>
                                            <i class="fas fa-star def-star"></i>
                                        </div>
                                    </div>
                                </div>
                                  <div class="card-body">
                                    <p class="card-text">هذه المنصة رائعه ف طريقة الكتابة والتنسيق ودايما بيبهروني بكل اللي بيعملوه</p>
                                  </div>
                                 </div>
                              </div>
                          </div>
                          <div class="owl-item active">
                              <div class="item">
                                 <div class="card">
                                    <div class="media">
                                    <img src="{{url('/front/imgs/128.jpg')}}" class="align-self-start mr-3" alt="...">
                                    <div class="media-body">
                                        <h5 class="mt-0">غاده محمد</h5>
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star def-star"></i>
                                            <i class="fas fa-star def-star"></i>
                                        </div>
                                    </div>
                                </div>
                                  <div class="card-body">
                                    <p class="card-text">هذه المنصة رائعه ف طريقة الكتابة والتنسيق ودايما بيبهروني بكل اللي بيعملوه</p>
                                  </div>
                                 </div>
                              </div>
                          </div>
                      </div>
                    </div>
                </div>
            </div>
        </section>