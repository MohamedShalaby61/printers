        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container">
              <a class="navbar-brand" href="###"><img src="{{url('/front/imgs/logo2.png')}}" alt="logo"></a>
              <div class="" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                  <li class="nav-item active">
                    <a href="#" class="nav-link btn btn-primary hvr-icon-pulse-grow" data-toggle="modal" data-target="#sign_in">
          تسجيل الدخول<i class="fas fa-sign-in-alt hvr-icon"></i>
            </a>
                  </li>
                  <li class="nav-item active">
                       <a href="#" class="error_must_login nav-link btn chg-color hvr-shutter-out-horizontal hvr-icon-pulse-grow" data-container="body" data-toggle="popover" data-placement="bottom">
					انشاء طلب<i class="fas fa-print hvr-icon"></i>
				    </a>

                  </li>
                  
                  <li class="nav-item active">
                       <div id="mySidenav" class="sidenav">
                          <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                          <a  onclick="closeNav()" href="#home" >الرئيسية</a>
                          {{--<a  onclick="closeNav()" href="#about">من نحن</a>--}}
                          <a  onclick="closeNav()" href="#services">خدماتنا</a>
                          <a  onclick="closeNav()" href="#how_print">كيفية الطباعة</a>
                          <a  onclick="closeNav()" href="#testmonials">أراء العملاء</a>
                          <a  onclick="closeNav()" href="#contact">تواصل معنا</a>
                           <a  onclick="closeNav()" href="#" class="error_must_login nav-link btn chg-color hvr-shutter-out-horizontal hvr-icon-pulse-grow">
                            انشاء طلب<i class="fas fa-print hvr-icon"></i>
                           </a>

                           <a href="#"  onclick="closeNav()" class="nav-link btn btn-primary hvr-shutter-out-horizontal hvr-icon-pulse-grow" data-toggle="modal" data-target="#sign_in">
					       تسجيل الدخول<i class="fas fa-sign-in-alt hvr-icon"></i>
				          </a>
                        </div>
                        <span style="font-size:30px;cursor:pointer" onclick="openNav()" ><i class="fas fa-bars menu trans-2s"></i></span>
                 </li>
                    
                </ul>
              </div>
            </div>
        </nav>
                    <!-- END navbar -->
        <div class="bg-head" id="home">
            <div class="overlay"></div>
            <div class="container">
                <div class="content-head text-center">
                    <h1 class="mb-30"><span style="color: #4e9bd4;">اطبع لي</span> | منصتك الالكترونية للكتابة والتنسيق</h1>
                    <p class="lead">بها تحفظ وقتك ومعها توفر مالك</p>
                </div>
            </div>
        </div>