<div class="" style="background-color: #fff; text-align: right; padding: 10px; box-shadow: 1px 1px 10px rgba(0,0,0,0.2); direction: rtl; font-family: 'Droid Arabic Naskh', serif;">
    <img src="{{ url('/') }}/print.png" style="width: 150px; height: 150px;" alt="logo">
    <h1 style="text-align: right;">مرحبا بكم في منصة إطبع لي</h1>
    <h2 style="text-align: right;">يمكنك إستخدام كلمة المرور الجديده هذه لتسجيل الدخول : {{ $native }}</h2>
		
                    <br><h4>شكرا لكم<h4>

                    <h4>إطبع لي<h4>  <br> 


                   واتس آب : 00966558756708<br>
                    البريد الالكتروني : printerterky@gmail.com
</div>